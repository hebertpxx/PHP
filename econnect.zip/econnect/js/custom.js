//Troca da estrela 1
function trocaImg(){

	var ed = document.getElementById('estrela-desligada')
	var el = document.getElementById('estrela-ligada')

	if(ed){
		document.getElementById('estrela-desligada').id = 'estrela-ligada';
	}
	
    if(el){
		document.getElementById('estrela-ligada').id = 'estrela-desligada';
	}
}


//Troca da estrela 2
function trocaImg2(){

	var ed = document.getElementById('estrela-desligada2')
	var el = document.getElementById('estrela-ligada2')

	if(ed){
		document.getElementById('estrela-desligada2').id = 'estrela-ligada2';
	}
	
    if(el){
		document.getElementById('estrela-ligada2').id = 'estrela-desligada2';
	}
}

//Troca da estrela 3
function trocaImg3(){

	var ed = document.getElementById('estrela-desligada3')
	var el = document.getElementById('estrela-ligada3')

	if(ed){
		document.getElementById('estrela-desligada3').id = 'estrela-ligada3';
	}
	
    if(el){
		document.getElementById('estrela-ligada3').id = 'estrela-desligada3';
	}
}

//Troca da estrela 4
function trocaImg4(){

	var ed = document.getElementById('estrela-desligada4')
	var el = document.getElementById('estrela-ligada4')

	if(ed){
		document.getElementById('estrela-desligada4').id = 'estrela-ligada4';
	}
	
    if(el){
		document.getElementById('estrela-ligada4').id = 'estrela-desligada4';
	}
}

//Troca da estrela 5
function trocaImg5(){

	var ed = document.getElementById('estrela-desligada5')
	var el = document.getElementById('estrela-ligada5')

	if(ed){
		document.getElementById('estrela-desligada5').id = 'estrela-ligada5';
	}
	
    if(el){
		document.getElementById('estrela-ligada5').id = 'estrela-desligada5';
	}
}